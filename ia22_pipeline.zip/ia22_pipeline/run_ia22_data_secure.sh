#!/usr/bin/env bash
set -euo pipefail

# IA22 - Pipeline de traitement sécurisé (prototype)
# Usage: ./run_ia22_data_secure.sh <num_records_optional>
NUM_RECORDS=${1:-1}
RAW_DIR="./ia22_raw"
TMP_DIR="./ia22_tmp"
OUT_DIR="./ia22_encrypted"
KEY_FILE="./ia22_key.bin"
LOG="./ia22_run.log"

mkdir -p "$RAW_DIR" "$TMP_DIR" "$OUT_DIR"
: > "$LOG"

timestamp() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
log() { echo "$(timestamp) - $*" | tee -a "$LOG"; }

# Generate or verify key
if [[ ! -f "$KEY_FILE" ]]; then
  log "Création d'une clé AES-256 (32 bytes) dans $KEY_FILE"
  head -c 32 /dev/urandom > "$KEY_FILE"
  chmod 600 "$KEY_FILE"
fi

KEY_HEX=$(xxd -p -c 256 "$KEY_FILE")
PASSPHRASE_ASCII=$(echo "$KEY_HEX" | xxd -r -p | base64)

log "Nettoyage anciens fichiers..."
rm -rf "$RAW_DIR"/* "$TMP_DIR"/* "$OUT_DIR"/*

# If there is no input JSON in RAW_DIR, copy example
if [[ -z "$(ls -A $RAW_DIR 2>/dev/null)" ]]; then
  if [[ -f "ia22_signal_example.json" ]]; then
    cp ia22_signal_example.json "$RAW_DIR/"
  fi
fi

# Process files
for f in "$RAW_DIR"/*.json; do
  [[ -e "$f" ]] || continue
  base=$(basename "$f" .json)
  log "Traitement: $base"

  # Validate & minify
  if ! jq -c . "$f" > "$TMP_DIR/${base}.min.json" 2>/dev/null; then
    log "Erreur JSON: $f - Ignoré"
    continue
  fi

  # Simulate binary serialization (store minified text as .bin for demo)
  cp "$TMP_DIR/${base}.min.json" "$TMP_DIR/${base}.bin"

  # Compress
  gzip -c "$TMP_DIR/${base}.bin" > "$TMP_DIR/${base}.bin.gz"

  # Encrypt using AES-256-GCM with openssl (authenticated)
  openssl enc -aes-256-gcm -pbkdf2 -iter 200000 -salt -pass pass:"$PASSPHRASE_ASCII" -in "$TMP_DIR/${base}.bin.gz" -out "$OUT_DIR/${base}.enc"
  log " > Fichier chiffré : $OUT_DIR/${base}.enc"

  # cleanup tmp for this file
  rm -f "$TMP_DIR/${base}.min.json" "$TMP_DIR/${base}.bin" "$TMP_DIR/${base}.bin.gz"
done

log "Processus terminé. Fichiers chiffrés dans $OUT_DIR"
