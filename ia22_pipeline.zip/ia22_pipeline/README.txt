IA22 Pipeline - Prototype
=========================
Contenu:
- ia22_signal_example.json : exemple de signal IA22 brut (JSON)
- run_ia22_data_secure.sh : script Bash prototype (minify -> compress -> AES-256-GCM encrypt)
- ia22_infer.py : script Python pour déchiffrement et inference TFLite (exemple)
- ia22_key.bin : *généré à l'exécution locale par le script Bash* (NE PAS COMMIT)
- ia22_report.pdf : fiche technique résumée (générée automatiquement)
- package ia22_pipeline.zip : archive contenant tous les éléments ci-dessus

Usage rapide:
1) Lancer le pipeline (créera ia22_key.bin si absent):
   chmod +x run_ia22_data_secure.sh
   ./run_ia22_data_secure.sh

2) Exécuter l'inférence (après avoir un modèle .tflite et un fichier .enc):
   python3 ia22_infer.py ia22_encrypted/ia22_signal_example.enc ia22_model.tflite

Sécurité:
- Ne stockez pas ia22_key.bin dans le dépôt.
- Pour production, utilisez un KMS (Hashicorp Vault, AWS KMS, etc.)
