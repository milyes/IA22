#!/usr/bin/env python3
import subprocess, json, sys, base64
from pathlib import Path
import numpy as np
import tensorflow as tf

def die(msg):
    print(msg)
    sys.exit(1)

if len(sys.argv) < 3:
    die("Usage: ia22_infer.py <encrypted_file.enc> <model.tflite>")

enc_file = Path(sys.argv[1])
model_file = Path(sys.argv[2])
key_file = Path("ia22_key.bin")

if not enc_file.exists():
    die(f"Encrypted file not found: {enc_file}")
if not model_file.exists():
    die(f"Model file not found: {model_file}")
if not key_file.exists():
    die("Key file (ia22_key.bin) missing")

# Prepare passphrase ASCII (derived same method as in the pipeline script)
key_hex = key_file.read_bytes().hex()
passphrase_ascii = base64.b64encode(bytes.fromhex(key_hex)).decode()

# Decrypt and gunzip
cmd = [
    "sh", "-c",
    f"openssl enc -d -aes-256-gcm -pbkdf2 -iter 200000 -salt -pass pass:'{passphrase_ascii}' -in '{enc_file}' | gunzip -c"
]
proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
if proc.returncode != 0:
    die(f"Decryption failed: {proc.stderr.decode()}")

minified_json = proc.stdout.decode()
data = json.loads(minified_json)

signal = data.get("signal_data", {})
features = [
    float(signal.get("channel_1_avg", 0.0)),
    float(signal.get("channel_2_freq", 0.0)),
    float(signal.get("channel_3_drift", 0.0)),
    float(signal.get("ia_intensity", 0.0))
]
input_arr = np.array([features], dtype=np.float32)

# Load tflite model
interpreter = tf.lite.Interpreter(model_path=str(model_file))
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

# Resize input if model expects different shape (best-effort)
try:
    interpreter.resize_tensor_input(input_details[0]['index'], input_arr.shape)
    interpreter.allocate_tensors()
except Exception as e:
    pass

interpreter.set_tensor(input_details[0]['index'], input_arr)
interpreter.invoke()
out = interpreter.get_tensor(output_details[0]['index'])
print("Inference result:", out)
