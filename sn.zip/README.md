Prototype minimal pour gérer des "capsules" (texte, audio, visuel) avec métadonnées signées.
Auteur: Zoubirou Mohammed Ilyes
ORCID: https://orcid.org/0009-0007-7571-3178